package moxy.compiler.ksp

import com.google.devtools.ksp.getDeclaredFunctions
import com.google.devtools.ksp.processing.KSPLogger
import com.google.devtools.ksp.symbol.ClassKind
import com.google.devtools.ksp.symbol.KSAnnotated
import com.google.devtools.ksp.symbol.KSAnnotation
import com.google.devtools.ksp.symbol.KSClassDeclaration
import com.google.devtools.ksp.symbol.KSFunctionDeclaration
import com.google.devtools.ksp.symbol.KSType
import com.google.devtools.ksp.symbol.Modifier
import com.squareup.javapoet.ArrayTypeName
import com.squareup.javapoet.ClassName
import com.squareup.javapoet.JavaFile
import com.squareup.javapoet.MethodSpec
import com.squareup.javapoet.ParameterSpec
import com.squareup.javapoet.ParameterizedTypeName
import com.squareup.javapoet.TypeName
import com.squareup.javapoet.TypeSpec
import com.squareup.javapoet.TypeVariableName
import moxy.MvpProcessor
import moxy.viewstate.MvpViewState
import moxy.viewstate.ViewCommand
import javax.lang.model.SourceVersion
import javax.lang.model.element.Modifier as JavaModifier

object ViewStateGenerator {

    fun generate(view: KSClassDeclaration, options: ViewStateOptions): JavaFile {
        val viewName = view.javaClassName()
        val typeName = view.javaSimpleName() + MvpProcessor.VIEW_STATE_SUFFIX
        val typeVariables = view.typeParameters.map { it.toTypeVariableName() }
        val viewType: TypeName = if (typeVariables.isEmpty()) {
            viewName
        } else {
            ParameterizedTypeName.get(viewName, *typeVariables.toTypedArray())
        }

        val classBuilder = TypeSpec.classBuilder(typeName)
            .addModifiers(JavaModifier.PUBLIC)
            .addTypeVariables(typeVariables)
            .superclass(ParameterizedTypeName.get(ClassName.get(MvpViewState::class.java), viewType))
            .addSuperinterface(viewType)

        for (method in collectMethods(view, options)) {
            val commandClass = generateCommandClass(method, viewType)
            classBuilder.addType(commandClass)
            classBuilder.addMethod(generateMethod(method, viewType, commandClass))
        }

        return JavaFile.builder(viewName.packageName(), classBuilder.build()).indent("\t").build()
    }

    private fun collectMethods(view: KSClassDeclaration, options: ViewStateOptions): List<ViewMethod> {
        val methods = ArrayList<ViewMethod>()
        val records = HashMap<String, MethodRecord>()
        val counter = HashMap<String, Int>()
        collectMethods(view, view, options, methods, records, counter)
        return methods
    }

    private fun collectMethods(
        view: KSClassDeclaration,
        declaration: KSClassDeclaration,
        options: ViewStateOptions,
        methods: MutableList<ViewMethod>,
        records: MutableMap<String, MethodRecord>,
        counter: MutableMap<String, Int>
    ) {
        val defaultStrategy = strategyClassOf(declaration, options.logger)
        for (function in declaration.getDeclaredFunctions()) {
            val name = function.simpleName.asString()
            if (name in IGNORED) continue
            if (Modifier.JAVA_STATIC in function.modifiers) continue
            reportNonVoidMethod(view, function, options)

            val signature = signatureOf(function)
            val explicitStrategy = strategyClassOf(function, options.logger) ?: defaultStrategy
            val existing = records[signature]
            if (existing != null) {
                reportSuperinterfaceClash(view, existing, declaration, function, explicitStrategy, options)
                continue
            }

            val strategy = explicitStrategy ?: emptyStrategy(view, function, options)
            records[signature] = MethodRecord(explicitStrategy, declaration)

            val seen = counter.getOrDefault(name, 0)
            counter[name] = seen + 1
            val suffix = if (seen > 0) seen.toString() else ""
            val typeVariables = function.typeParameters.map { it.toTypeVariableName() }
            val substitution = substitutionFor(view, function)
            val suppressWildcards = declaration.suppressesWildcards() || function.suppressesWildcards()
            val parameters = function.parameters.mapIndexed { index, parameter ->
                val parameterName = safeJavaName(parameter.name!!.asString(), index)
                val suppress = suppressWildcards || parameter.suppressesWildcards()
                var parameterType = parameter.type.resolve().toJavaTypeName(substitution, suppress)
                if (parameter.isVararg) parameterType = ArrayTypeName.of(parameterType)
                ParameterSpec.builder(parameterType, parameterName).build()
            }
            val varargs = function.parameters.lastOrNull()?.isVararg == true
            methods.add(ViewMethod(name, suffix, strategy, tagOf(function), typeVariables, parameters, varargs))
        }
        for (reference in declaration.superTypes) {
            val superDeclaration = reference.resolve().declaration as? KSClassDeclaration ?: continue
            if (superDeclaration.classKind != ClassKind.INTERFACE) continue
            if (superDeclaration.qualifiedName?.asString() == MVP_VIEW) continue
            collectMethods(view, superDeclaration, options, methods, records, counter)
        }
    }

    private fun reportNonVoidMethod(view: KSClassDeclaration, function: KSFunctionDeclaration, options: ViewStateOptions) {
        val returnType = function.returnType?.resolve() ?: return
        if (returnType.declaration.qualifiedName?.asString() == "kotlin.Unit") return
        options.logger.error(
            "You are trying to generate ViewState for ${view.simpleName.asString()}. " +
                "But ${view.simpleName.asString()} contains non-void method \"${function.simpleName.asString()}\" " +
                "with the return type of ${returnType.toJavaTypeName()}.",
            function
        )
    }

    private fun reportSuperinterfaceClash(
        view: KSClassDeclaration,
        existing: MethodRecord,
        declaration: KSClassDeclaration,
        function: KSFunctionDeclaration,
        strategy: ClassName?,
        options: ViewStateOptions
    ) {
        if (existing.owner.isSubInterfaceOf(declaration)) return
        if (strategy == null || existing.strategy == null || strategy == existing.strategy) return
        val parameters = function.parameters.joinToString { it.type.resolve().toJavaTypeName().toString() }
        options.logger.error(
            "Strategy clash in superinterfaces of ${view.simpleName.asString()}. " +
                "Interface ${declaration.simpleName.asString()} defines ${function.simpleName.asString()}($parameters) " +
                "with strategy ${strategy.simpleName()}, " +
                "but ${existing.owner.simpleName.asString()} defines this method with strategy ${existing.strategy.simpleName()}. " +
                "Override this method in ${view.simpleName.asString()} to choose appropriate strategy",
            view
        )
    }

    private fun KSClassDeclaration.isSubInterfaceOf(other: KSClassDeclaration): Boolean {
        val target = other.qualifiedName?.asString() ?: return false
        return superInterfaces().any { it.qualifiedName?.asString() == target }
    }

    private fun KSClassDeclaration.superInterfaces(): Sequence<KSClassDeclaration> = sequence {
        for (reference in superTypes) {
            val declaration = reference.resolve().declaration as? KSClassDeclaration ?: continue
            yield(declaration)
            yieldAll(declaration.superInterfaces())
        }
    }

    private fun emptyStrategy(
        view: KSClassDeclaration,
        function: KSFunctionDeclaration,
        options: ViewStateOptions
    ): ClassName {
        if (!options.disableEmptyStrategyCheck) {
            if (options.enableEmptyStrategyHelper) {
                options.migrationMethods.add(MigrationMethod(view, function))
            } else {
                options.logger.error(
                    "A View method has no strategy! Add @StateStrategyType annotation to this method, " +
                        "or to the View interface. You can also specify default strategy via compiler option.",
                    function
                )
            }
        }
        return options.frameworkDefaultStrategy
    }

    private fun signatureOf(function: KSFunctionDeclaration): String {
        val parameters = function.parameters.joinToString(",") {
            it.type.resolve().declaration.qualifiedName?.asString() ?: it.type.resolve().declaration.simpleName.asString()
        }
        return "${function.simpleName.asString()}($parameters)"
    }

    private fun substitutionFor(view: KSClassDeclaration, function: KSFunctionDeclaration): Map<String, TypeName> {
        val owner = function.parentDeclaration as? KSClassDeclaration ?: return emptyMap()
        if (owner.qualifiedName?.asString() == view.qualifiedName?.asString()) return emptyMap()
        return buildSubstitution(view, owner)
    }

    private fun buildSubstitution(from: KSClassDeclaration, owner: KSClassDeclaration): Map<String, TypeName> {
        var result: Map<String, TypeName> = emptyMap()
        fun walk(declaration: KSClassDeclaration, incoming: Map<String, TypeName>): Boolean {
            for (reference in declaration.superTypes) {
                val superType = reference.resolve()
                val superDeclaration = superType.declaration as? KSClassDeclaration ?: continue
                val map = HashMap<String, TypeName>()
                superDeclaration.typeParameters.forEachIndexed { index, parameter ->
                    val argument = superType.arguments.getOrNull(index)?.type?.resolve() ?: return@forEachIndexed
                    map[parameter.name.asString()] = argument.toJavaTypeName(incoming)
                }
                if (superDeclaration.qualifiedName?.asString() == owner.qualifiedName?.asString()) {
                    result = map
                    return true
                }
                if (walk(superDeclaration, map)) return true
            }
            return false
        }
        walk(from, emptyMap())
        return result
    }

    private fun strategyClassOf(annotated: KSAnnotated, logger: KSPLogger): ClassName? {
        val strategies = annotated.annotations.mapNotNull { annotation ->
            if (annotation.shortName.asString() == STATE_STRATEGY_TYPE) {
                strategyValue(annotation)
            } else {
                (annotation.annotationType.resolve().declaration as? KSClassDeclaration)?.annotations
                    ?.firstOrNull { it.shortName.asString() == STATE_STRATEGY_TYPE }
                    ?.let { strategyValue(it) }
            }
        }.toList()
        if (strategies.size > 1) reportMultipleStrategies(annotated, logger)
        return strategies.firstOrNull()
    }

    private fun reportMultipleStrategies(annotated: KSAnnotated, logger: KSPLogger) {
        when (annotated) {
            is KSFunctionDeclaration -> {
                val parameters = annotated.parameters.joinToString { it.type.resolve().toJavaTypeName().toString() }
                val owner = (annotated.parentDeclaration as? KSClassDeclaration)?.qualifiedName?.asString()
                logger.error(
                    "There's more than one state strategy type defined for method " +
                        "'${annotated.simpleName.asString()}($parameters)' in interface '$owner'",
                    annotated
                )
            }
            is KSClassDeclaration -> {
                logger.error(
                    "There's more than one state strategy type defined for '${annotated.simpleName.asString()}'",
                    annotated
                )
            }
        }
    }

    private fun strategyValue(annotation: KSAnnotation): ClassName? {
        val value = annotation.arguments.firstOrNull { it.name?.asString() == "value" }?.value as? KSType ?: return null
        return (value.declaration as? KSClassDeclaration)?.javaClassName()
    }

    private fun tagOf(function: KSFunctionDeclaration): String {
        val tag = function.annotations
            .firstOrNull { it.shortName.asString() == STATE_STRATEGY_TYPE }
            ?.arguments?.firstOrNull { it.name?.asString() == "tag" }?.value as? String
        return tag?.takeUnless { it.isEmpty() } ?: function.simpleName.asString()
    }

    private fun generateCommandClass(method: ViewMethod, viewType: TypeName): TypeSpec {
        val constructor = MethodSpec.constructorBuilder()
            .addParameters(method.parameters)
            .varargs(method.varargs)
            .addStatement("super(\$S, \$T.class)", method.tag, method.strategy)
        if (method.parameters.isNotEmpty()) constructor.addCode("\n")
        for (parameter in method.parameters) constructor.addStatement("this.\$N = \$N", parameter, parameter)

        val applyMethod = MethodSpec.methodBuilder("apply")
            .addAnnotation(Override::class.java)
            .addModifiers(JavaModifier.PUBLIC)
            .addParameter(viewType, "mvpView")
            .addStatement("mvpView.\$L(\$L)", method.name, method.argumentsString)
            .build()

        val classBuilder = TypeSpec.classBuilder(method.commandClassName)
            .addModifiers(JavaModifier.PUBLIC)
            .addTypeVariables(method.typeVariables)
            .superclass(ParameterizedTypeName.get(ClassName.get(ViewCommand::class.java), viewType))
            .addMethod(constructor.build())
            .addMethod(applyMethod)
        for (parameter in method.parameters) {
            classBuilder.addField(parameter.type, parameter.name, JavaModifier.PUBLIC, JavaModifier.FINAL)
        }
        return classBuilder.build()
    }

    private fun generateMethod(method: ViewMethod, viewType: TypeName, commandClass: TypeSpec): MethodSpec {
        var commandField = decapitalize(method.commandClassName)
        var iterationVar = "view"
        // Add salt if the method has an argument with the same name
        while (method.argumentsString.contains(commandField)) commandField += (commandField.hashCode() % 10)
        while (method.argumentsString.contains(iterationVar)) iterationVar += (iterationVar.hashCode() % 10)

        return MethodSpec.methodBuilder(method.name)
            .addAnnotation(Override::class.java)
            .addModifiers(JavaModifier.PUBLIC)
            .addTypeVariables(method.typeVariables)
            .varargs(method.varargs)
            .returns(TypeName.VOID)
            .addParameters(method.parameters)
            .addStatement("\$N \$L = new \$N(\$L)", commandClass, commandField, commandClass, method.argumentsString)
            .addStatement("this.viewCommands.beforeApply(\$L)", commandField)
            .addCode("\n")
            .beginControlFlow("if (hasNotView())")
            .addStatement("return")
            .endControlFlow()
            .addCode("\n")
            .beginControlFlow("for (\$T $iterationVar : this.views)", viewType)
            .addStatement("$iterationVar.\$L(\$L)", method.name, method.argumentsString)
            .endControlFlow()
            .addCode("\n")
            .addStatement("this.viewCommands.afterApply(\$L)", commandField)
            .build()
    }

    private fun decapitalize(value: String): String =
        if (value.isEmpty()) value else value[0].lowercaseChar() + value.substring(1)

    // A Kotlin parameter name may be a Java keyword (e.g. 'new'); the generated $$State is Java, so rename it.
    // The name is only used as a command field and for positional replay, so any valid unique name works.
    private fun safeJavaName(name: String, index: Int): String = when {
        SourceVersion.isName(name) -> name
        SourceVersion.isKeyword(name) -> "${name}_"
        else -> "arg$index"
    }

    private fun KSAnnotated.suppressesWildcards(): Boolean {
        val annotation = annotations.firstOrNull { it.shortName.asString() == "JvmSuppressWildcards" } ?: return false
        return annotation.arguments.firstOrNull { it.name?.asString() == "suppress" }?.value as? Boolean ?: true
    }

    private const val STATE_STRATEGY_TYPE = "StateStrategyType"
    private const val MVP_VIEW = "moxy.MvpView"
    private val IGNORED = setOf("equals", "hashCode", "toString", "<init>")

    private class MethodRecord(
        val strategy: ClassName?,
        val owner: KSClassDeclaration
    )

    private class ViewMethod(
        val name: String,
        uniqueSuffix: String,
        val strategy: ClassName,
        val tag: String,
        val typeVariables: List<TypeVariableName>,
        val parameters: List<ParameterSpec>,
        val varargs: Boolean
    ) {
        val commandClassName: String = name.replaceFirstChar { it.uppercaseChar() } + uniqueSuffix + "Command"
        val argumentsString: String = parameters.joinToString { it.name }
    }
}
