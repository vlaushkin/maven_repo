package moxy.compiler.ksp

import com.squareup.javapoet.JavaFile
import com.squareup.javapoet.MethodSpec
import com.squareup.javapoet.TypeSpec
import javax.lang.model.element.Modifier

object EmptyStrategyHelperGenerator {

    fun generate(migrationMethods: List<MigrationMethod>): JavaFile {
        val exampleView = migrationMethods.first().viewInterface.javaSimpleName()

        val javaDoc = """
            This class is generated because 'enableEmptyStrategyHelper' compiler option is set to true.


            All view methods must have a strategy. Please, add the @StateStrategyType annotation
            to the methods listed below. You can also set this annotation directly to the View interface.

            Do not pay attention to compilation errors like
            'error: $exampleView is abstract; cannot be instantiated'

            Just use your IDE to navigate to the methods and set the required strategy for them.
            After you've fixed all the methods, you can remove 'enableEmptyStrategyHelper' option
            for the current module.

        """.trimIndent()

        val method = MethodSpec.methodBuilder("getViewStateProviders")
            .addModifiers(Modifier.PUBLIC, Modifier.STATIC)
            .addComment("If you are using Intellij IDEA or Android Studio, use Go to declaration (Ctrl/⌘+B or Ctrl/⌘+Click)")
            .addComment("to navigate to '${migrationMethods.first().method.simpleName.asString()}()'")
        for (migration in migrationMethods) {
            method.addStatement(
                "new \$L().\$L()",
                migration.viewInterface.qualifiedName!!.asString(),
                migration.method.simpleName.asString()
            )
        }

        val classBuilder = TypeSpec.classBuilder("EmptyStrategyHelper")
            .addModifiers(Modifier.PUBLIC, Modifier.FINAL)
            .addJavadoc(javaDoc)
            .addMethod(method.build())

        return JavaFile.builder("moxy", classBuilder.build()).indent("\t").build()
    }
}
