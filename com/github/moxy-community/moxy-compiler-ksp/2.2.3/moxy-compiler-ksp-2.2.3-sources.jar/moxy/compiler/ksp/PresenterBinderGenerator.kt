package moxy.compiler.ksp

import com.google.devtools.ksp.getConstructors
import com.google.devtools.ksp.getDeclaredProperties
import com.google.devtools.ksp.symbol.ClassKind
import com.google.devtools.ksp.symbol.KSAnnotated
import com.google.devtools.ksp.symbol.KSClassDeclaration
import com.google.devtools.ksp.symbol.KSFunctionDeclaration
import com.google.devtools.ksp.symbol.KSPropertyDeclaration
import com.google.devtools.ksp.symbol.KSType
import com.squareup.javapoet.ClassName
import com.squareup.javapoet.JavaFile
import com.squareup.javapoet.MethodSpec
import com.squareup.javapoet.ParameterizedTypeName
import com.squareup.javapoet.TypeName
import com.squareup.javapoet.TypeSpec
import com.squareup.javapoet.WildcardTypeName
import moxy.MvpPresenter
import moxy.MvpProcessor
import moxy.PresenterBinder
import moxy.presenter.PresenterField
import java.util.ArrayList
import javax.lang.model.element.Modifier

object PresenterBinderGenerator {

    fun generate(target: KSClassDeclaration, injectedFields: List<KSPropertyDeclaration>): JavaFile {
        val targetName = target.javaClassName()
        val functions = target.getAllFunctions().toList()
        val providers = functions.filter { it.hasAnnotation(PROVIDE_PRESENTER) }
        val tagProviders = functions.filter { it.hasAnnotation(PROVIDE_PRESENTER_TAG) }
        val fields = injectedFields.map { field(it, providers, tagProviders) }

        val classBuilder = TypeSpec.classBuilder(target.javaSimpleName() + MvpProcessor.PRESENTER_BINDER_SUFFIX)
            .addModifiers(Modifier.PUBLIC)
            .superclass(ParameterizedTypeName.get(ClassName.get(PresenterBinder::class.java), targetName))

        for (field in fields) classBuilder.addType(generateFieldBinder(field, targetName))
        classBuilder.addMethod(generateGetPresenterFields(fields, targetName, findSuperContainer(target)))

        return JavaFile.builder(targetName.packageName(), classBuilder.build()).indent("\t").build()
    }

    private fun findSuperContainer(target: KSClassDeclaration): KSClassDeclaration? {
        var current = target.superClassDeclaration()
        while (current != null) {
            if (current.getDeclaredProperties().any { it.hasAnnotation(INJECT_PRESENTER) }) return current
            current = current.superClassDeclaration()
        }
        return null
    }

    private fun KSClassDeclaration.superClassDeclaration(): KSClassDeclaration? =
        superTypes.map { it.resolve().declaration }
            .filterIsInstance<KSClassDeclaration>()
            .firstOrNull { it.classKind == ClassKind.CLASS && it.qualifiedName?.asString() != "kotlin.Any" }

    private fun generateGetPresenterFields(
        fields: List<Field>,
        targetName: ClassName,
        superContainer: KSClassDeclaration?
    ): MethodSpec {
        val fieldType = ParameterizedTypeName.get(
            ClassName.get(PresenterField::class.java), WildcardTypeName.supertypeOf(targetName)
        )
        val listType = ParameterizedTypeName.get(ClassName.get(List::class.java), fieldType)

        val builder = MethodSpec.methodBuilder("getPresenterFields")
            .addAnnotation(Override::class.java)
            .addModifiers(Modifier.PUBLIC)
            .returns(listType)
            .addStatement("\$T presenters = new \$T<>(\$L)", listType, ClassName.get(ArrayList::class.java), fields.size)
        for (field in fields) builder.addStatement("presenters.add(new \$L())", field.binderClassName)
        if (superContainer != null) {
            val superBinder = superContainer.qualifiedName!!.asString() + MvpProcessor.PRESENTER_BINDER_SUFFIX
            builder.addStatement("presenters.addAll(new \$L().getPresenterFields())", superBinder)
        }
        return builder.addStatement("return presenters").build()
    }

    private fun generateFieldBinder(field: Field, targetName: ClassName): TypeSpec {
        val constructor = MethodSpec.constructorBuilder()
            .addModifiers(Modifier.PUBLIC)
            .addStatement("super(\$S, \$S, \$T.class)", field.tag, field.presenterId, field.presenterType)
            .build()

        val bind = MethodSpec.methodBuilder("bind")
            .addAnnotation(Override::class.java)
            .addModifiers(Modifier.PUBLIC)
            .addParameter(targetName, "target")
            .addParameter(MvpPresenter::class.java, "presenter")
            .addStatement("target.\$L = (\$T) presenter", field.name, field.presenterType)
            .build()

        val providePresenter = MethodSpec.methodBuilder("providePresenter")
            .addAnnotation(Override::class.java)
            .addModifiers(Modifier.PUBLIC)
            .returns(ParameterizedTypeName.get(ClassName.get(MvpPresenter::class.java), WildcardTypeName.subtypeOf(Any::class.java)))
            .addParameter(targetName, "delegated")
            .apply {
                when {
                    field.provideMethodName != null -> addStatement("return delegated.\$L()", field.provideMethodName)
                    field.hasEmptyConstructor -> addStatement("return new \$T()", field.presenterType)
                    else -> addStatement(
                        "throw new \$T(\$S)", IllegalStateException::class.java,
                        "${field.presenterType} hasn't got a default constructor. You can apply @ProvidePresenter " +
                            "to a method which will construct Presenter. Otherwise you can add empty constructor to presenter."
                    )
                }
            }
            .build()

        val binder = TypeSpec.classBuilder(field.binderClassName)
            .addModifiers(Modifier.PUBLIC)
            .superclass(ParameterizedTypeName.get(ClassName.get(PresenterField::class.java), targetName))
            .addMethod(constructor)
            .addMethod(bind)
            .addMethod(providePresenter)

        if (field.tagProviderMethodName != null) {
            binder.addMethod(
                MethodSpec.methodBuilder("getTag")
                    .addAnnotation(Override::class.java)
                    .addModifiers(Modifier.PUBLIC)
                    .returns(String::class.java)
                    .addParameter(targetName, "delegated")
                    .addStatement("return String.valueOf(delegated.\$L())", field.tagProviderMethodName)
                    .build()
            )
        }

        return binder.build()
    }

    private fun field(
        field: KSPropertyDeclaration,
        providers: List<KSFunctionDeclaration>,
        tagProviders: List<KSFunctionDeclaration>
    ): Field {
        val name = field.simpleName.asString()
        val declaration = field.type.resolve().declaration as KSClassDeclaration
        val typeName = declaration.qualifiedName?.asString()
        val presenterType = declaration.javaClassName()
        val presenterId = annotationArgument(field, INJECT_PRESENTER, "presenterId").ifEmpty { null }
        val provideMethod = providers.firstOrNull {
            (it.returnType?.resolve()?.declaration as? KSClassDeclaration)?.qualifiedName?.asString() == typeName
        }
        val tagProvider = tagProviders.firstOrNull {
            tagProviderPresenterClass(it)?.qualifiedName?.asString() == typeName &&
                annotationArgument(it, PROVIDE_PRESENTER_TAG, "presenterId").ifEmpty { null } == presenterId
        }
        val hasEmptyConstructor = declaration.getConstructors().any { it.parameters.isEmpty() }

        return Field(
            name = name,
            presenterType = presenterType,
            tag = annotationArgument(field, INJECT_PRESENTER, "tag").ifEmpty { name },
            presenterId = presenterId,
            provideMethodName = provideMethod?.simpleName?.asString(),
            tagProviderMethodName = tagProvider?.simpleName?.asString(),
            hasEmptyConstructor = hasEmptyConstructor
        )
    }

    private fun tagProviderPresenterClass(function: KSFunctionDeclaration): KSClassDeclaration? {
        val annotation = function.annotations.firstOrNull { it.shortName.asString() == PROVIDE_PRESENTER_TAG } ?: return null
        val value = annotation.arguments.firstOrNull { it.name?.asString() == "presenterClass" }?.value as? KSType
        return value?.declaration as? KSClassDeclaration
    }

    private fun annotationArgument(annotated: KSAnnotated, annotationName: String, name: String): String {
        val annotation = annotated.annotations.firstOrNull { it.shortName.asString() == annotationName } ?: return ""
        return annotation.arguments.firstOrNull { it.name?.asString() == name }?.value as? String ?: ""
    }

    private fun KSAnnotated.hasAnnotation(name: String): Boolean = annotations.any { it.shortName.asString() == name }

    private const val INJECT_PRESENTER = "InjectPresenter"
    private const val PROVIDE_PRESENTER = "ProvidePresenter"
    private const val PROVIDE_PRESENTER_TAG = "ProvidePresenterTag"

    private class Field(
        val name: String,
        val presenterType: ClassName,
        val tag: String,
        val presenterId: String?,
        val provideMethodName: String?,
        val tagProviderMethodName: String?,
        val hasEmptyConstructor: Boolean
    ) {
        val binderClassName: String = name.replaceFirstChar { it.uppercaseChar() } + MvpProcessor.PRESENTER_BINDER_INNER_SUFFIX
    }
}
