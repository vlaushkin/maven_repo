package moxy.compiler.ksp

import com.google.devtools.ksp.symbol.KSClassDeclaration
import com.squareup.javapoet.ClassName
import com.squareup.javapoet.JavaFile
import com.squareup.javapoet.MethodSpec
import com.squareup.javapoet.ParameterizedTypeName
import com.squareup.javapoet.TypeSpec
import com.squareup.javapoet.WildcardTypeName
import moxy.MvpProcessor
import moxy.MvpView
import moxy.ViewStateProvider
import moxy.viewstate.MvpViewState
import javax.lang.model.element.Modifier

object ViewStateProviderGenerator {

    fun generate(presenter: KSClassDeclaration, view: KSClassDeclaration): JavaFile {
        val presenterName = presenter.javaClassName()

        var className = presenterName.simpleName() + MvpProcessor.VIEW_STATE_PROVIDER_SUFFIX
        var enclosing = presenterName.enclosingClassName()
        while (enclosing != null) {
            className = "${enclosing.simpleName()}$$className"
            enclosing = enclosing.enclosingClassName()
        }

        val viewState = ClassName.get(view.packageName.asString(), view.javaSimpleName() + MvpProcessor.VIEW_STATE_SUFFIX)

        val getViewState = MethodSpec.methodBuilder("getViewState")
            .addAnnotation(Override::class.java)
            .addModifiers(Modifier.PUBLIC)
            .returns(
                ParameterizedTypeName.get(
                    ClassName.get(MvpViewState::class.java),
                    WildcardTypeName.subtypeOf(MvpView::class.java)
                )
            )
            .addStatement("return new \$T()", viewState)
            .build()

        val typeSpec = TypeSpec.classBuilder(className)
            .addModifiers(Modifier.PUBLIC)
            .superclass(ViewStateProvider::class.java)
            .addMethod(getViewState)
            .build()

        return JavaFile.builder(presenterName.packageName(), typeSpec).indent("\t").build()
    }
}
