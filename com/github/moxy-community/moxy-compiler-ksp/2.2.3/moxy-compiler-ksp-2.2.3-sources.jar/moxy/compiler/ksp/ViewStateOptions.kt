package moxy.compiler.ksp

import com.google.devtools.ksp.processing.KSPLogger
import com.google.devtools.ksp.symbol.KSClassDeclaration
import com.google.devtools.ksp.symbol.KSFunctionDeclaration
import com.squareup.javapoet.ClassName

class ViewStateOptions(
    val frameworkDefaultStrategy: ClassName,
    val disableEmptyStrategyCheck: Boolean,
    val enableEmptyStrategyHelper: Boolean,
    val logger: KSPLogger,
    val migrationMethods: MutableList<MigrationMethod>
)

class MigrationMethod(
    val viewInterface: KSClassDeclaration,
    val method: KSFunctionDeclaration
)
