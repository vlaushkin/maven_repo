package moxy.compiler.ksp

import com.google.devtools.ksp.symbol.ClassKind
import com.google.devtools.ksp.symbol.KSClassDeclaration
import com.google.devtools.ksp.symbol.KSDeclaration
import com.google.devtools.ksp.symbol.KSType
import com.google.devtools.ksp.symbol.KSTypeAlias
import com.google.devtools.ksp.symbol.KSTypeArgument
import com.google.devtools.ksp.symbol.KSTypeParameter
import com.google.devtools.ksp.symbol.Modifier
import com.google.devtools.ksp.symbol.Variance
import com.squareup.javapoet.ArrayTypeName
import com.squareup.javapoet.ClassName
import com.squareup.javapoet.ParameterizedTypeName
import com.squareup.javapoet.TypeName
import com.squareup.javapoet.TypeVariableName
import com.squareup.javapoet.WildcardTypeName

fun KSClassDeclaration.javaClassName(): ClassName {
    val simpleNames = nestedSimpleNames()
    return ClassName.get(packageName.asString(), simpleNames.first(), *simpleNames.drop(1).toTypedArray())
}

fun KSClassDeclaration.javaSimpleName(): String = nestedSimpleNames().joinToString("$")

private fun KSClassDeclaration.nestedSimpleNames(): List<String> {
    val names = ArrayList<String>()
    var declaration: KSClassDeclaration? = this
    while (declaration != null) {
        names.add(0, declaration.simpleName.asString())
        declaration = declaration.parentDeclaration as? KSClassDeclaration
    }
    return names
}

fun KSTypeParameter.toTypeVariableName(): TypeVariableName {
    val bounds = bounds.map { it.resolve().toJavaTypeName() }.filter { it != TypeName.OBJECT }.toList()
    return if (bounds.isEmpty()) {
        TypeVariableName.get(name.asString())
    } else {
        TypeVariableName.get(name.asString(), *bounds.toTypedArray())
    }
}

fun KSType.toJavaTypeName(
    substitution: Map<String, TypeName> = emptyMap(),
    suppressWildcards: Boolean = false
): TypeName {
    val declaration = declaration
    if (declaration is KSTypeParameter) {
        val name = declaration.name.asString()
        return substitution[name] ?: TypeVariableName.get(name)
    }
    if (declaration is KSTypeAlias) {
        // KSP does not expand typealiases; expand to the underlying type (substituting the alias' own arguments).
        val aliasSubstitution = HashMap(substitution)
        declaration.typeParameters.forEachIndexed { index, parameter ->
            arguments.getOrNull(index)?.type?.resolve()?.let {
                aliasSubstitution[parameter.name.asString()] = it.toJavaTypeName(substitution, suppressWildcards)
            }
        }
        return declaration.type.resolve().toJavaTypeName(aliasSubstitution, suppressWildcards)
    }

    val qualifiedName = declaration.qualifiedName?.asString()

    PRIMITIVE_ARRAYS[qualifiedName]?.let { return it }
    if (qualifiedName == KOTLIN_ARRAY) {
        val component = arguments.firstOrNull()?.type?.resolve()?.toJavaTypeName(substitution, suppressWildcards) ?: TypeName.OBJECT
        return ArrayTypeName.of(component.box())
    }

    if (arguments.isEmpty()) {
        PRIMITIVE_TYPES[qualifiedName]?.let { return if (isMarkedNullable) BOXED_TYPES.getValue(qualifiedName!!) else it }
        return rawClassName(qualifiedName, declaration)
    }

    val raw = rawClassName(qualifiedName, declaration)
    val typeParameters = (declaration as? KSClassDeclaration)?.typeParameters.orEmpty()
    val typeArguments = arguments.mapIndexed { index, argument ->
        projectTypeArgument(argument, typeParameters.getOrNull(index)?.variance ?: Variance.INVARIANT, substitution, suppressWildcards)
    }
    return ParameterizedTypeName.get(raw, *typeArguments.toTypedArray())
}

// Kotlin projects declaration-site variance ('List<out E>', 'Function1<in P1, out R>') into Java wildcards
// in the generated JVM signature; the $$State override must repeat it. 'out' to a final class adds no wildcard.
private fun projectTypeArgument(
    argument: KSTypeArgument,
    declarationVariance: Variance,
    substitution: Map<String, TypeName>,
    suppressWildcards: Boolean
): TypeName {
    val annotations = argument.type?.annotations?.toList().orEmpty()
    val forceWildcard = annotations.any { it.shortName.asString() == "JvmWildcard" }
    val suppress = !forceWildcard &&
        (suppressWildcards || annotations.any { it.shortName.asString() == "JvmSuppressWildcards" })

    if (argument.variance == Variance.STAR) {
        return if (suppress) TypeName.OBJECT else WildcardTypeName.subtypeOf(TypeName.OBJECT)
    }
    val resolved = argument.type?.resolve() ?: return WildcardTypeName.subtypeOf(TypeName.OBJECT)
    val type = resolved.toJavaTypeName(substitution, suppressWildcards).box()
    if (suppress) return type
    return when {
        argument.variance == Variance.CONTRAVARIANT || declarationVariance == Variance.CONTRAVARIANT ->
            WildcardTypeName.supertypeOf(type)
        forceWildcard ||
            ((argument.variance == Variance.COVARIANT || declarationVariance == Variance.COVARIANT) && !resolved.isFinalClass()) ->
            WildcardTypeName.subtypeOf(type)
        else -> type
    }
}

private fun KSType.isFinalClass(): Boolean {
    val declaration = declaration as? KSClassDeclaration ?: return false
    if (declaration.classKind == ClassKind.INTERFACE) return false
    return Modifier.OPEN !in declaration.modifiers &&
        Modifier.ABSTRACT !in declaration.modifiers &&
        Modifier.SEALED !in declaration.modifiers
}

private fun rawClassName(qualifiedName: String?, declaration: KSDeclaration): ClassName {
    MAPPED_CLASSES[qualifiedName]?.let { return it }
    if (qualifiedName != null && FUNCTION_TYPE.matches(qualifiedName)) {
        return ClassName.get("kotlin.jvm.functions", declaration.simpleName.asString())
    }
    return (declaration as? KSClassDeclaration)?.javaClassName() ?: ClassName.bestGuess(qualifiedName.orEmpty())
}

private const val KOTLIN_ARRAY = "kotlin.Array"
private val FUNCTION_TYPE = Regex("kotlin\\.Function\\d+")

private val MAPPED_CLASSES = mapOf(
    "kotlin.Any" to ClassName.get("java.lang", "Object"),
    "kotlin.String" to ClassName.get("java.lang", "String"),
    "kotlin.CharSequence" to ClassName.get("java.lang", "CharSequence"),
    "kotlin.Number" to ClassName.get("java.lang", "Number"),
    "kotlin.Comparable" to ClassName.get("java.lang", "Comparable"),
    "kotlin.Throwable" to ClassName.get("java.lang", "Throwable"),
    "kotlin.collections.List" to ClassName.get("java.util", "List"),
    "kotlin.collections.MutableList" to ClassName.get("java.util", "List"),
    "kotlin.collections.Map" to ClassName.get("java.util", "Map"),
    "kotlin.collections.MutableMap" to ClassName.get("java.util", "Map"),
    "kotlin.collections.Set" to ClassName.get("java.util", "Set"),
    "kotlin.collections.MutableSet" to ClassName.get("java.util", "Set"),
    "kotlin.collections.Collection" to ClassName.get("java.util", "Collection"),
    "kotlin.collections.MutableCollection" to ClassName.get("java.util", "Collection"),
    "kotlin.collections.Iterable" to ClassName.get("java.lang", "Iterable"),
    "kotlin.collections.MutableIterable" to ClassName.get("java.lang", "Iterable"),
    "kotlin.collections.ArrayList" to ClassName.get("java.util", "ArrayList"),
    "kotlin.collections.HashMap" to ClassName.get("java.util", "HashMap"),
    "kotlin.collections.LinkedHashMap" to ClassName.get("java.util", "LinkedHashMap"),
    "kotlin.collections.HashSet" to ClassName.get("java.util", "HashSet"),
    "kotlin.collections.LinkedHashSet" to ClassName.get("java.util", "LinkedHashSet")
)

private val PRIMITIVE_TYPES = mapOf(
    "kotlin.Int" to TypeName.INT,
    "kotlin.Long" to TypeName.LONG,
    "kotlin.Short" to TypeName.SHORT,
    "kotlin.Byte" to TypeName.BYTE,
    "kotlin.Boolean" to TypeName.BOOLEAN,
    "kotlin.Char" to TypeName.CHAR,
    "kotlin.Float" to TypeName.FLOAT,
    "kotlin.Double" to TypeName.DOUBLE
)

private val BOXED_TYPES = mapOf(
    "kotlin.Int" to ClassName.get("java.lang", "Integer"),
    "kotlin.Long" to ClassName.get("java.lang", "Long"),
    "kotlin.Short" to ClassName.get("java.lang", "Short"),
    "kotlin.Byte" to ClassName.get("java.lang", "Byte"),
    "kotlin.Boolean" to ClassName.get("java.lang", "Boolean"),
    "kotlin.Char" to ClassName.get("java.lang", "Character"),
    "kotlin.Float" to ClassName.get("java.lang", "Float"),
    "kotlin.Double" to ClassName.get("java.lang", "Double")
)

private val PRIMITIVE_ARRAYS = mapOf(
    "kotlin.IntArray" to ArrayTypeName.of(TypeName.INT),
    "kotlin.LongArray" to ArrayTypeName.of(TypeName.LONG),
    "kotlin.ShortArray" to ArrayTypeName.of(TypeName.SHORT),
    "kotlin.ByteArray" to ArrayTypeName.of(TypeName.BYTE),
    "kotlin.BooleanArray" to ArrayTypeName.of(TypeName.BOOLEAN),
    "kotlin.CharArray" to ArrayTypeName.of(TypeName.CHAR),
    "kotlin.FloatArray" to ArrayTypeName.of(TypeName.FLOAT),
    "kotlin.DoubleArray" to ArrayTypeName.of(TypeName.DOUBLE)
)
