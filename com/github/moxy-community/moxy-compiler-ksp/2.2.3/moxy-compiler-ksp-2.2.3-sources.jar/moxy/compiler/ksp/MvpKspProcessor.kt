package moxy.compiler.ksp

import com.google.devtools.ksp.processing.Dependencies
import com.google.devtools.ksp.processing.Resolver
import com.google.devtools.ksp.processing.SymbolProcessor
import com.google.devtools.ksp.processing.SymbolProcessorEnvironment
import com.google.devtools.ksp.processing.SymbolProcessorProvider
import com.google.devtools.ksp.symbol.ClassKind
import com.google.devtools.ksp.symbol.KSAnnotated
import com.google.devtools.ksp.symbol.KSClassDeclaration
import com.google.devtools.ksp.symbol.KSDeclaration
import com.google.devtools.ksp.symbol.KSPropertyDeclaration
import com.google.devtools.ksp.symbol.KSType
import com.google.devtools.ksp.symbol.KSTypeAlias
import com.google.devtools.ksp.symbol.KSTypeParameter
import com.google.devtools.ksp.symbol.Modifier
import com.squareup.javapoet.ClassName
import com.squareup.javapoet.JavaFile
import moxy.viewstate.strategy.AddToEndSingleStrategy

class MvpKspProcessor(
    private val environment: SymbolProcessorEnvironment
) : SymbolProcessor {

    private var processed = false

    override fun process(resolver: Resolver): List<KSAnnotated> {
        if (processed) return emptyList()
        processed = true

        val annotated = resolver.getSymbolsWithAnnotation(INJECT_VIEW_STATE)
            .filterIsInstance<KSClassDeclaration>()
        val inherited = resolver.getAllFiles()
            .flatMap { file -> file.declarations.flatMap { it.allClassDeclarations() } }
            .filter { it.isMvpPresenter() }
        val presenters = (annotated + inherited)
            .filter { it.classKind == ClassKind.CLASS && Modifier.ABSTRACT !in it.modifiers }
            .distinctBy { it.qualifiedName?.asString() }
            .toList()

        val options = resolveOptions(resolver)

        val usedViews = LinkedHashMap<String, KSClassDeclaration>()
        for (presenter in presenters) {
            val view = presenter.resolveViewType() ?: continue
            usedViews[view.qualifiedName!!.asString()] = view
            write(ViewStateProviderGenerator.generate(presenter, view), presenter)
        }

        for (view in usedViews.values) {
            write(ViewStateGenerator.generate(view, options), *viewHierarchy(view))
        }

        val targets = resolver.getSymbolsWithAnnotation(INJECT_PRESENTER)
            .filterIsInstance<KSPropertyDeclaration>()
            .groupBy { it.parentDeclaration as KSClassDeclaration }
        for ((target, fields) in targets) {
            fields.forEach { validateInjectPresenter(target, it) }
            write(PresenterBinderGenerator.generate(target, fields), target)
        }

        if (options.enableEmptyStrategyHelper && options.migrationMethods.isNotEmpty()) {
            writeFile(EmptyStrategyHelperGenerator.generate(options.migrationMethods), Dependencies(true))
        }

        return emptyList()
    }

    private fun resolveOptions(resolver: Resolver): ViewStateOptions {
        val options = environment.options
        return ViewStateOptions(
            frameworkDefaultStrategy = resolveDefaultStrategy(resolver, options[DEFAULT_MOXY_STRATEGY]),
            disableEmptyStrategyCheck = options[DISABLE_EMPTY_STRATEGY_CHECK]?.toBoolean() ?: false,
            enableEmptyStrategyHelper = options[ENABLE_EMPTY_STRATEGY_HELPER]?.toBoolean() ?: false,
            logger = environment.logger,
            migrationMethods = mutableListOf()
        )
    }

    private fun resolveDefaultStrategy(resolver: Resolver, name: String?): ClassName {
        if (name == null) return DEFAULT_STATE_STRATEGY
        val declaration = resolver.getClassDeclarationByName(resolver.getKSNameFromString(name))
        if (declaration == null) {
            environment.logger.error("Unable to parse option '$DEFAULT_MOXY_STRATEGY'. Check $name exists")
            return DEFAULT_STATE_STRATEGY
        }
        return declaration.javaClassName()
    }

    private fun write(javaFile: JavaFile, vararg origins: KSClassDeclaration) {
        val files = origins.mapNotNull { it.containingFile }.distinct().toTypedArray()
        writeFile(javaFile, Dependencies(false, *files))
    }

    private fun writeFile(javaFile: JavaFile, dependencies: Dependencies) {
        environment.codeGenerator
            .createNewFile(dependencies, javaFile.packageName, javaFile.typeSpec.name, "java")
            .bufferedWriter()
            .use { javaFile.writeTo(it) }
    }

    private fun viewHierarchy(view: KSClassDeclaration): Array<KSClassDeclaration> {
        val declarations = LinkedHashSet<KSClassDeclaration>()
        declarations.add(view)
        view.superTypeChain().mapNotNull { it.declaration as? KSClassDeclaration }.forEach { declarations.add(it) }
        return declarations.toTypedArray()
    }

    private fun validateInjectPresenter(target: KSClassDeclaration, field: KSPropertyDeclaration) {
        val presenter = field.type.resolve().declaration as? KSClassDeclaration ?: return
        val viewName = presenter.resolveViewType()?.qualifiedName?.asString() ?: return
        if (target.superTypeChain().none { it.qualifiedName == viewName }) {
            environment.logger.error(
                "You can not use @InjectPresenter in a class that is not a View typed with target Presenter",
                field
            )
        }
    }

    // getAllFiles().declarations is top-level only; recurse so nested presenters are discovered too.
    private fun KSDeclaration.allClassDeclarations(): Sequence<KSClassDeclaration> = sequence {
        if (this@allClassDeclarations is KSClassDeclaration) {
            yield(this@allClassDeclarations)
            declarations.forEach { yieldAll(it.allClassDeclarations()) }
        }
    }

    private fun KSClassDeclaration.isMvpPresenter(): Boolean =
        superTypeChain().any { it.qualifiedName == MVP_PRESENTER }

    private fun KSClassDeclaration.resolveViewType(): KSClassDeclaration? = resolveViewType(emptyMap())

    private fun KSClassDeclaration.resolveViewType(substitution: Map<String, KSType>): KSClassDeclaration? {
        for (reference in superTypes) {
            var superType = reference.resolve()
            var currentSubstitution = substitution
            while (superType.declaration is KSTypeAlias) {
                val alias = superType.declaration as KSTypeAlias
                val aliasSubstitution = HashMap<String, KSType>()
                alias.typeParameters.forEachIndexed { index, parameter ->
                    superType.arguments.getOrNull(index)?.type?.resolve()?.let {
                        aliasSubstitution[parameter.name.asString()] = substitute(it, currentSubstitution)
                    }
                }
                currentSubstitution = aliasSubstitution
                superType = alias.type.resolve()
            }
            val superDeclaration = superType.declaration as? KSClassDeclaration ?: continue
            if (superDeclaration.qualifiedName?.asString() == MVP_PRESENTER) {
                val argument = superType.arguments.firstOrNull()?.type?.resolve() ?: return null
                return substitute(argument, currentSubstitution).declaration as? KSClassDeclaration
            }
            val nextSubstitution = HashMap<String, KSType>()
            superDeclaration.typeParameters.forEachIndexed { index, parameter ->
                val argument = superType.arguments.getOrNull(index)?.type?.resolve() ?: return@forEachIndexed
                nextSubstitution[parameter.name.asString()] = substitute(argument, currentSubstitution)
            }
            superDeclaration.resolveViewType(nextSubstitution)?.let { return it }
        }
        return null
    }

    private fun substitute(type: KSType, substitution: Map<String, KSType>): KSType {
        val declaration = type.declaration
        if (declaration is KSTypeParameter) {
            return substitution[declaration.name.asString()] ?: type
        }
        return type
    }

    private fun KSClassDeclaration.superTypeChain(): Sequence<KSType> = sequence {
        for (reference in superTypes) {
            var type = reference.resolve()
            while (type.declaration is KSTypeAlias) {
                type = (type.declaration as KSTypeAlias).type.resolve()
            }
            yield(type)
            (type.declaration as? KSClassDeclaration)?.let { yieldAll(it.superTypeChain()) }
        }
    }

    private val KSType.qualifiedName: String?
        get() = declaration.qualifiedName?.asString()

    companion object {
        private const val MVP_PRESENTER = "moxy.MvpPresenter"
        private const val INJECT_VIEW_STATE = "moxy.InjectViewState"
        private const val INJECT_PRESENTER = "moxy.presenter.InjectPresenter"
        private const val DEFAULT_MOXY_STRATEGY = "defaultMoxyStrategy"
        private const val DISABLE_EMPTY_STRATEGY_CHECK = "disableEmptyStrategyCheck"
        private const val ENABLE_EMPTY_STRATEGY_HELPER = "enableEmptyStrategyHelper"
        private val DEFAULT_STATE_STRATEGY: ClassName = ClassName.get(AddToEndSingleStrategy::class.java)
    }
}

class MvpKspProcessorProvider : SymbolProcessorProvider {

    override fun create(environment: SymbolProcessorEnvironment): SymbolProcessor {
        return MvpKspProcessor(environment)
    }
}
