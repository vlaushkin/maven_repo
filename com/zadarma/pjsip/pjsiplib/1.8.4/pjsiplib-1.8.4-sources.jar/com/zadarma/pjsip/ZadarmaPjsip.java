package com.zadarma.pjsip;

/**
 * @author Vasily Laushkin <vaslinux@gmail.com> on 22/06/2018.
 */
public class ZadarmaPjsip {
    static {
        System.loadLibrary("native-lib");
    }

    // Version constants are generated from versions.properties (single source of truth)
    // into PjsipBuildConfig at build time, so they can never drift from the published AAR.
    public static final String PJSIP_COMMIT = PjsipBuildConfig.PJSIP_COMMIT;
    public static final String PJSIP_VERSION = PjsipBuildConfig.PJSIP_VERSION;
    public static final String ZADARMA_PJSIP_VERSION = PjsipBuildConfig.ZADARMA_PJSIP_VERSION;

    public static final boolean SSL_ENABLED = true;
    public static final boolean VIDEO_ENABLED = false;
    public static final boolean G729_ENABLED = true;

    /* configure params & build instructions moved to README.md */

    public static native void setDns(String[] nameservers);
}
