package com.zadarma.pjsip;

/**
 * GENERATED from versions.properties by the :pjsiplib Gradle build — do not edit.
 * Single source of truth for the versions surfaced at runtime by {@link ZadarmaPjsip}.
 */
public final class PjsipBuildConfig {
    private PjsipBuildConfig() {}

    public static final String ZADARMA_PJSIP_VERSION = "1.8.4";
    public static final String PJSIP_VERSION = "2.17";
    public static final String PJSIP_COMMIT = "5a457451fa2712ba18e12b01738e8ff3af2b26fd";
}
