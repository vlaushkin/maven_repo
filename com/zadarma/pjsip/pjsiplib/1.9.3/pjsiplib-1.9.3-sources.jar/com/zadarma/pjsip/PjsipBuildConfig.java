package com.zadarma.pjsip;

/**
 * GENERATED from versions.properties by the :pjsiplib Gradle build — do not edit.
 * Single source of truth for the versions surfaced at runtime by {@link ZadarmaPjsip}.
 */
public final class PjsipBuildConfig {
    private PjsipBuildConfig() {}

    public static final String ZADARMA_PJSIP_VERSION = "1.9.3";
    public static final String PJSIP_VERSION = "2.17-dev";
    public static final String PJSIP_COMMIT = "4e023d03abf8bd05c315c1ddd28e0bbefffa87f6";
}
