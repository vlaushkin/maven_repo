package com.zadarma.pjsip;

/**
 * @author Vasily Laushkin <vaslinux@gmail.com> on 22/06/2018.
 */
public class ZadarmaPjsip {
    static {
        System.loadLibrary("native-lib");
    }

    public static final String PJSIP_COMMIT = "5a457451fa2712ba18e12b01738e8ff3af2b26fd"; // https://github.com/pjsip/pjproject/commit/5a457451fa2712ba18e12b01738e8ff3af2b26fd
    public static final String PJSIP_VERSION = "2.17";
    public static final String ZADARMA_PJSIP_VERSION = "1.8.0";

    public static final boolean SSL_ENABLED = true;
    public static final boolean VIDEO_ENABLED = false;
    public static final boolean G729_ENABLED = true;

    /* configure params & build instructions moved to README.md */

    public static native void setDns(String[] nameservers);
}
