package com.zadarma.pjsip;

/**
 * GENERATED from versions.properties by the :pjsiplib Gradle build — do not edit.
 * Single source of truth for the versions surfaced at runtime by {@link ZadarmaPjsip}.
 */
public final class PjsipBuildConfig {
    private PjsipBuildConfig() {}

    public static final String ZADARMA_PJSIP_VERSION = "1.9.7";
    public static final String PJSIP_VERSION = "2.18-dev";
    public static final String PJSIP_COMMIT = "f1f3c9e5adac514304e018b27c192d23241cc8eb";
}
