package org.pjsip.zadarma;

import java.nio.charset.StandardCharsets;

/**
 * The pjsip log, kept in a native ring buffer that survives the process.
 *
 * <p>Every line pjlib logs at or below {@code LogConfig.level} is copied by a
 * native log writer into a file mapped into memory ({@code mmap MAP_SHARED}),
 * with no call into Java per line. The pages are the kernel's, so what was
 * written before a native crash, an abort or a kill by the low memory killer is
 * still there when the next process starts; that process reads it back with
 * {@link #previousTail(int)}. A power loss can lose the last few seconds.
 *
 * <p>The ring takes every level {@code LogConfig.level} lets through, while
 * {@code LogConfig.consoleLevel} still decides what reaches a Java
 * {@code LogWriter}: the native writer chains to the one pjsua installs, so the
 * log file and the Java callback keep working as before.
 *
 * <p>A thread spinning on an error cannot flush the ring. One thread may store
 * one line (the same text, ignoring the time stamp) 3 times a second; more of
 * it in that second is counted instead, and once the second is over a line
 * such as {@code [logring] 152043 more of "android_jni_dev.c  Player thread:
 * Error 0 writing data" in 1.000 s} records the count. A spin that goes on
 * costs a few lines a second, whatever order its lines come in.
 *
 * <h2>Order of calls</h2>
 * <ol>
 *   <li>{@code Endpoint.libCreate()}</li>
 *   <li>{@link #enable(String, int)} -- once per process</li>
 *   <li>{@code Endpoint.libInit(cfg)}</li>
 *   <li>{@link #install()} -- after <em>every</em> {@code libInit}, which puts
 *       pjsua's own writer back in place of ours</li>
 * </ol>
 *
 * <h2>Threads</h2>
 * Every method may be called from any thread, including one pjlib does not
 * know about (a crash reporter's, the main thread): none of them calls into
 * pjlib in a way that needs {@code libRegisterThread}. {@link #tail(int)}
 * copies the ring under the same lock the writer takes, for about the time a
 * {@code memcpy} of the ring takes, and formats it outside the lock.
 *
 * <p>pjsip runs only in the main process. Calling this from another process
 * works, but that process then writes a ring of its own named after its pid.
 */
public final class PjLogRing {
    static {
        System.loadLibrary("pjsua2");
    }

    /** {@link #enable} took the ring file at {@code path}. */
    public static final int MODE_PRIMARY = 1;
    /**
     * {@link #enable} found {@code path} locked by another live process and
     * writes {@code path.<pid>} instead. The previous process's ring is then not
     * this process's to read.
     */
    public static final int MODE_FALLBACK = 2;

    /** The ring size the design was sized for: about 10 calls at level 4. */
    public static final int DEFAULT_SIZE = 1024 * 1024;

    private PjLogRing() {
    }

    /**
     * Opens the ring of this process and installs the native log writer.
     *
     * <p>The ring left by the previous process at {@code path} moves to
     * {@code path + ".prev"} first, where {@link #previousTail} reads it. Also
     * created next to it: {@code path + ".lock"}.
     *
     * <p>Once per process: a second call changes nothing, re-installs the writer
     * and returns the mode of the first.
     *
     * @param path the ring file, e.g. {@code new File(context.getFilesDir(),
     *     "pjsip-log/ring").getPath()}; its directory must exist
     * @param sizeBytes the data size, clamped to 64 KiB .. 16 MiB
     * @return {@link #MODE_PRIMARY} or {@link #MODE_FALLBACK}, or a negative
     *     errno (e.g. -28, ENOSPC) when the ring could not be set up; logging
     *     then works exactly as without it
     */
    public static int enable(String path, int sizeBytes) {
        if (path == null) {
            throw new NullPointerException("path");
        }
        return nativeEnable(path, sizeBytes);
    }

    /**
     * Puts the native writer back in front of the current pjlib log writer.
     * Call it after every {@code Endpoint.libInit()}, which installs pjsua's own.
     * Idempotent.
     *
     * @return true if it was not installed and now is; false if it already was,
     *     or {@link #enable} has not succeeded
     */
    public static boolean install() {
        return nativeInstall();
    }

    /** Whether pjlib's current log writer is ours. */
    public static boolean isInstalled() {
        return nativeIsInstalled();
    }

    /**
     * The newest whole lines of this process's ring, at most {@code maxBytes}
     * of UTF-8, after a line that describes the ring.
     *
     * @return the text, or null if the ring is not enabled
     */
    public static String tail(int maxBytes) {
        return decode(nativeTail(maxBytes));
    }

    /**
     * The newest whole lines the previous process left, at most
     * {@code maxBytes}, and marks them read: the next call returns null, in this
     * process and in every later one, so a crash is reported once.
     *
     * @return the text, or null if there is none, it was already read, or
     *     {@link #enable} has not succeeded
     */
    public static String previousTail(int maxBytes) {
        return decode(nativePreviousTail(maxBytes));
    }

    /**
     * Stores a line of the app's own in the ring, in time order with pjsip's:
     * the same record, time stamp and thread id, the same masking of secrets
     * and the same repeat guard as a pjsip line. Lines longer than 4096 bytes of
     * UTF-8 are cut. Any thread, before {@code Endpoint.libCreate()} too; pjlib
     * is not involved, so the line does not reach pjsua's log writer.
     *
     * @return false if the ring is not enabled or the line is null or empty
     */
    public static boolean write(String line) {
        if (line == null || line.isEmpty()) {
            return false;
        }
        return nativeWrite(line.getBytes(StandardCharsets.UTF_8));
    }

    /** Lines the repeat guard has kept out of the ring since {@link #enable}. */
    public static long suppressedRepeats() {
        return nativeSuppressedRepeats();
    }

    /**
     * The most times one thread logged one line in a second (this second or the
     * one before), among lines logged in the last 2 seconds; 0 if no line came
     * more than 3 times. Thousands mean a thread is spinning on an error -- a
     * signal that holds even when that thread logs nothing a crash report
     * would carry.
     */
    public static long repeatRate() {
        return nativeRepeatRate();
    }

    private static String decode(byte[] bytes) {
        return bytes == null ? null : new String(bytes, StandardCharsets.UTF_8);
    }

    private static native int nativeEnable(String path, int sizeBytes);

    private static native boolean nativeInstall();

    private static native boolean nativeIsInstalled();

    private static native byte[] nativeTail(int maxBytes);

    private static native byte[] nativePreviousTail(int maxBytes);

    private static native long nativeSuppressedRepeats();

    private static native long nativeRepeatRate();

    private static native boolean nativeWrite(byte[] line);
}
