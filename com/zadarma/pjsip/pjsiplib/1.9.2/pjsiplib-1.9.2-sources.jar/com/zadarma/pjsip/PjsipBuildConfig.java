package com.zadarma.pjsip;

/**
 * GENERATED from versions.properties by the :pjsiplib Gradle build — do not edit.
 * Single source of truth for the versions surfaced at runtime by {@link ZadarmaPjsip}.
 */
public final class PjsipBuildConfig {
    private PjsipBuildConfig() {}

    public static final String ZADARMA_PJSIP_VERSION = "1.9.2";
    public static final String PJSIP_VERSION = "2.17-dev";
    public static final String PJSIP_COMMIT = "c7fa6bfb85172f038cf37986696a16b3987391ea";
}
